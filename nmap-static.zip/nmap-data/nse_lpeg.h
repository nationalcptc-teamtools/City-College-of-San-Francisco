#ifndef LPEG

#define LPEG
#define LPEGLIBNAME "lpeg"

LUALIB_API int luaopen_lpeg (lua_State *L);

#endif
