#ifndef OPENSSLLIB
#define OPENSSLLIB

#define OPENSSLLIBNAME "openssl"

LUALIB_API int luaopen_openssl(lua_State *L);

#endif

