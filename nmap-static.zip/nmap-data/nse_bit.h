#ifndef BITLIB
#define BITLIB

#define BITLIBNAME "bit"

LUALIB_API int luaopen_bit(lua_State *L);

#endif

