#ifndef NSE_BINLIB
#define NSE_BINLIB

#define NSE_BINLIBNAME "bin"

LUALIB_API int luaopen_binlib (lua_State *L);

#endif /* NSE_BINLIB */

