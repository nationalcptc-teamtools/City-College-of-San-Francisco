1. scp the archive onto the machine
	scp ./nmap-static.zip balthazar@10.10.110.100:~/.evil

2. ssh into the machine
	ssh balthazar@10.10.110.100

3. unzip the archive
	cd .evil
	unzip ./nmap_static.zip

4. chmod +x the nmap binary
	chmod +x ./nmap

5. Run nmap and be happy
	nmap --datadir ./nmap-data -vv -sV 172.16.1.12
